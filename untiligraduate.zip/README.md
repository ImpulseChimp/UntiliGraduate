## Until I Graduate Website

While I should have been studying one night in college I joked around with a couple other students that I should make
a college graduation countdown website. The purpose would be to track, to the second, how much time I would have left before I graduated with a nice pleasing picture to look at while it ticked down. A few hours later, while I should have been doing homework, I put together the base site structure with a few jQuery plugins and started using it as my default chrome tab. Since then, it has turned into a small side project that I maintain for anybody that wants it.

Website: www.untiligraduate.com

#### jQuery Plugins Used (as of this writing)
* FlipClock http://flipclockjs.com/
* Lettering js http://letteringjs.com/
* Avgrund http://lab.hakim.se/avgrund/
* Pick Date http://amsul.ca/pickadate.js/date/

For any errors found on the site or improvements wanted to the site, please submit an issue with the appropriate
tag to document the problem/improvement.
